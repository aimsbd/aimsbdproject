<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gender_mst extends Model
{
    protected $table = 'gender_msts';

	protected $fillable = ['Gender_mstID', 'GenderNAME', 'Delete_CD', 'User', 'Ip'];
}
