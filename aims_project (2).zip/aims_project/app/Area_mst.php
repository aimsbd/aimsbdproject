<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Area_mst extends Model
{
    protected $table = 'area_msts';

    protected $fillable = ['Area_Code', 'Company_Code','Area_Name', 'Company_Code','Area_Delete_Cd','Area_User','Area_IP'];
}
