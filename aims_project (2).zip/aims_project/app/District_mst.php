<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class District_mst extends Model
{
    protected $table = 'district_msts';

    protected $fillable = ['District_Code', 'Area_Code','District_Name', 'Dist_Delete_Cd','Dist_User','Dist_IP'];
}
