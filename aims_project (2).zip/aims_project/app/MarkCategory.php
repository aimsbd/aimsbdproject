<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MarkCategory extends Model
{
    protected $fillable = ['add_category'];
}
