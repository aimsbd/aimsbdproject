<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Artical_mst extends Model
{
    protected $table = 'artical_msts';

    protected $fillable = ['Articl_mstID', 'Group', 'Type', 'Upper_Materiais', 'Color','Artical_Code','Similar_Artical','Initial_Week','Initial_Date','Artical_Name','Project','Category_mstID','Sub_category_mstID','Brand_mstID','Country_of_Origin',
'Supplier','Supplier_Reference','Artical_Type','Currency','BTN_Tariff_Code','Collection_Type','Collection_Name','Target_Customer','Type_Of_Construction','Upper','Lining','Outsole','Features','Other_Color','Type_Of_Development','Artical_Description','Estimated_SOR','Selling_Period','Channel','Introduction_Week',
'Expt-Delv-Month','Sale_By_Week','Artical_Image','Price_Group','Price_1','Price_2','MRP_1','MRP_2',
'Finpack_Type','Finpack_Price','Standard_Cost','Manuacture_Cost','Purchase_Cost','Cost_Local','FOB_Cost','FOB_Currency','Awg_Weight','Height','Width','Length','Artical_Size_Code','R1',
'R2','R3','R4','R5','R6','R7','R8','R9','R10','R11','R12','R13','R14','R15','R16','Artical_delete_Cd','Artical_user','Artical_iP'];
}
