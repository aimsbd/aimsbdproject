<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Brand_mst extends Model
{
    // protected $primaryKey = 'Brand_mstID'; // or null

    // public $incrementing = false;

    protected $table = 'brand_msts';

	protected $fillable = ['Brand_mstID', 'Brand_Name', 'delete_Cd', 'user', 'Ip'];
}
