<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ClassList;

class ClassListsController extends Controller
{
   

    public function index()

    {
      
        $classlist = ClassList::all();
          
        return view('classlist.index',['sa'=> $classlist]);

    }


    
    public function add(Request $request)
 {
    $this->validate($request, [
        'classId'=> 'required',
        'className' => 'required'
   
     ]);
     $classlist = new ClassList;
     $classlist->classId=$request->input('classId');
    
     $classlist->className=$request->input('className');
     $classlist->classLevel=$request->input('classLevel');

     $classlist->save();
     return redirect('/classlist')->with('info','Class list saved successfully');
 }


 

  public function edit()

  {

    return view('classlist.edit');
  }
}
