<?php

namespace App\Http\Controllers;

use App\MarkCategory;
use Illuminate\Http\Request;

class MarkCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $markcategories = MarkCategory::all();
        
        return view('MarkCategory.index',compact('markcategories'))
        ->with('i', (request()->input('page', 1) - 1) * 5);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('MarkCategory.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'add_category' => 'required'
            
        
        ]);


        MarkCategory::create($request->all());


        return view('MarkCategory.index')
                        ->with('success','Category created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MarkCategory  $markCategory
     * @return \Illuminate\Http\Response
     */
    public function show(MarkCategory $markCategory)
    {
        return view('MarkCategory.show',compact('markCategory'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MarkCategory  $markCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(MarkCategory $markCategory)
    {
        return view('MarkCategory.edit',compact('$markCategory'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MarkCategory  $markCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MarkCategory $markCategory)
    {
        $this->validate($request, [
            'add_category' => 'required',
            
        ]);


        $product->update($request->all());
        

        return redirect()->route('markcategory ')
                        ->with('success','Product updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MarkCategory  $markCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(MarkCategory $markCategory)
    {
        $mark_category->delete();


        return redirect()->route('markcategory')
                        ->with('success','Product deleted successfully');
    }


    public function test()

    {
     echo 'HEllo';
     die();
         
    }
}
