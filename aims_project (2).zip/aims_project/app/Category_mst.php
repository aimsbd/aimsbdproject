<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category_mst extends Model
{
    protected $table = 'gender_msts';

	protected $fillable = ['Category_mstID', 'Category_Name', 'Delete_Cd', 'User', 'IP'];
}
