<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company_mst extends Model
{
    protected $table = 'company_msts';

    protected $fillable = ['Company_Code', 'Company_Name','Company_Address', 'Company_District','Company_Thana','Company_City','Company_Country','Company_Email','Comapny_Phone','Company_delet_cd','Company_user','Company_Ip'];
}
