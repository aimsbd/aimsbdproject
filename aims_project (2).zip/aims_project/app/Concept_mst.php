<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Concept_mst extends Model
{
    protected $table = 'concept_msts';

    protected $fillable = ['Concept_Code', 'Concept_Code','Concept_Name', 'Company_Code','Conpt_Delete_Cd','Conpt_User','Conpt_IP'];
}
