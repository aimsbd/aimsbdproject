<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee_mst extends Model
{
    protected $table = 'employee_msts';

    protected $fillable =['Emp_Code', 'Company_Code','Emp_Name','Emp_Address','Emp_District','Emp_Thana','Emp_City','Emp_Country'];

}
