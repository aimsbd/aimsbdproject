<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Store_mst extends Model
{
    protected $table = 'store_msts';

    protected $fillable =['Store_Code', 'Store_Name','Store_Address','Store_District','Store_Thana','Store_City','Store_Country','Store_Opening_Date','Store_Closing_Date','Store_Rent','Store_Initial_Week','Store_Advanced','District_Code','Rent_Pay_Date','Shope_Manager','Concept_Code','Store_Delete_Cd','Store_User','Store_IP',''];
}
