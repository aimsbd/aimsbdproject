<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sub_Category_mst extends Model
{
    // protected $primaryKey = 'Sub_category_mstID'; // or null

    // public $incrementing = false;

    protected $table = 'sub__category_msts';

	protected $fillable = ['Sub_category_mstID', 'Sub_category_Name', 'delete_cd', 'user', 'Ip'];
}
