<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCreateacademicclenderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('createacademicclender', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('month');
            $table->string('selectBox');
            $table->datetime('date');
            $table->integer('day');
            $table->string('eventName');
            $table->string('eventDescription');
            $table->string('se;ectColor');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('createacademicclender');
    }
}
