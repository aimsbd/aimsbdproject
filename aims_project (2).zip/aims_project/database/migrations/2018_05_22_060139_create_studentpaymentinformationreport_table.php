<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentpaymentinformationreportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('studentpaymentinformationreport', function (Blueprint $table) {
            $table->increments('id');
            $table->string('paymentHead');
            $table->datetime('fromDate');
            $table->datetime('toDate');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('studentpaymentinformationreport');
    }
}
