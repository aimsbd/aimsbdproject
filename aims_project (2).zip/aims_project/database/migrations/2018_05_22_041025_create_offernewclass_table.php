<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOffernewclassTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('offernewclass', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('classLevel');
            $table->string('className');
            $table->string('medium');
            $table->string('group');
            $table->string('shift');
            $table->string('section');
            $table->string('session');
            $table->string('formMaster');
            $table->integer('totalSeat');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('offernewclass');
    }
}
