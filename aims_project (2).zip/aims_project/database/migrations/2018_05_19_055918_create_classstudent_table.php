<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClassstudentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('classstudent', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('classId');
            $table->integer('sectionId');
            $table->integer('rollNo');
            $table->string('year');
            $table->integer('status');
            $table->datetime('createdDate');
            $table->string('createdBy');
            $table->datetime('updatedDate');
            $table->string('updatedBy');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('classstudent');
    }
}
