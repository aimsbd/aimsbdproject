<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRecordborrowedbooksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('recordborrowedbooks', function (Blueprint $table) {
            $table->increments('id');
            $table->string('bokName');
            $table->string('studentId');
            $table->datetime('bookisssueDate');
            $table->datetime('bookreturnDate');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('recordborrowedbooks');
    }
}
