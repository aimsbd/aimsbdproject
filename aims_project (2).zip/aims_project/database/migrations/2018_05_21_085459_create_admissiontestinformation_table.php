<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdmissiontestinformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admissiontestinformation', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('session');
            $table->integer('classLevel');
            $table->integer('class');
            $table->string('medium');
            $table->string('group');
            $table->string('shift');
            $table->datetime('examDate');
            $table->datetime('examTime');
            $table->string('bangla');
            $table->string('english');
            $table->string('mathmatics');
            $table->string('generalKnowledge');
            $table->string('totalMarks');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admissiontestinformation');
    }
}
