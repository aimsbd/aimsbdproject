<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInsertbookinfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('insertbookinfo', function (Blueprint $table) {
            $table->increments('id');
            $table->string('bookName');
            $table->string('bookWriter');
            $table->string('bookCategory');
            $table->datetime('bookBuyingdate');
            $table->string('bookPrice');
            $table->string('totalbookPrice');
            $table->integer('bookStatus');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('insertbookinfo');
    }
}
