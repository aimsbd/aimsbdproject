<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateApplicantTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('applicant', function (Blueprint $table) {
            $table->increments('applicantid');
            $table->string('name');
            $table->string('fatherName');
            $table->string('motherName');
            $table->integer('classId');
            $table->string('session');
            $table->string('image');
            $table->string('result');
            $table->integer('gender');
            $table->datetime('dateOfBirth');
            $table->integer('status');
            $table->datetime('createDate');
            $table->string('createBy');
            $table->datetime('updatedDate');
            $table->string('updateBY');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('applicant');
    }
}
