<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAddemployeeattendanceinformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addemployeeattendanceinformation', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('select');
            $table->string('employeeinfo');
            $table->integer('attendance');
            $table->integer('reason');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addemployeeattendanceinformation');
    }
}
