<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCompanyMstsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('company_msts', function (Blueprint $table) {
            //$table->increments('id');
            $table->string('Company_Code');
            $table->string('Company_Name');
            $table->string('Company_Address');
            $table->string('Company_District');
            $table->string('Company_Thana');
            $table->string('Company_City');
            $table->string('Company_Country');
            $table->string('Company_Email');
            $table->string('Comapny_Phone');
            $table->string('Company_delet_cd');
            $table->string('Company_user');
            $table->string('Company_Ip');
            $table->timestamps();
            $table->primary('Company_Code');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('company_msts');
    }
}
