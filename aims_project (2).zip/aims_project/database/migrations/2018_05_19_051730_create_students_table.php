<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->increments('studenid');
            $table->integer('applicantid')->unsigned()->nullable();
            $table->string('phone');
            $table->string('email');
            $table->integer('religions');
            $table->integer('classId');
            $table->string('nationality');
            $table->string('bloodgroup');
            $table->integer('snId');
            $table->string('fatherProfession');
            $table->string('string');
            $table->string('fatherPhoto');
            $table->integer('fnId');
            $table->string('motherProfession');
            $table->string('motherPhone');
            $table->string('motherPhoto');
            $table->integer('mnId');
            $table->string('presentAddress');
            $table->string('premanentAddress');
            $table->integer('status');
            $table->datetime('createdDate');
            $table->string('createdBy');
            $table->datetime('updatedDate');
            $table->string('updatedBy');

              
            $table->foreign('applicantid')
                  ->references('applicantid')->on('applicant')
                  ->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}
