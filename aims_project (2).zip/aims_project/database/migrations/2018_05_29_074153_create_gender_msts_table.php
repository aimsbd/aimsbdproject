<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGenderMstsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('gender_msts', function (Blueprint $table) {
            //$table->increments('id');
            $table->string('Gender_mstID');
            $table->primary('Gender_mstID');
            $table->string('GenderNAME');
            $table->string('Delete_CD');
            $table->string('User');
            $table->string('Ip');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('gender_msts');
    }
}
