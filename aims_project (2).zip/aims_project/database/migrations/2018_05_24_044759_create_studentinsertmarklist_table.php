<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentinsertmarklistTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('studentinsertmarklist', function (Blueprint $table) {
            $table->increments('id');
            $table->string('session');
            $table->string('class');
            $table->string('medium');
            $table->string('shift');
            $table->string('section');
            $table->string('group');
            $table->string('subjectName');
            $table->integer('exam');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('studentinsertmarklist');
    }
}
