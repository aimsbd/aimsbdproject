<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateArticalMstsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('artical_msts', function (Blueprint $table) {
            //$table->increments('id');
            $table->string('articl_mstID')->primary(); 
            $table->string('artical_Name');
            $table->string('delete_Cd');
            $table->string('user');
            $table->string('iP');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('artical_msts');
    }
}
