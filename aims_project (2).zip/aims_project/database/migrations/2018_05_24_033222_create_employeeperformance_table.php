<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmployeeperformanceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employeeperformance', function (Blueprint $table) {
            $table->increments('id');
            $table->string('department');
            $table->string('designation');
            $table->integer('employeeType');
            $table->integer('employeementStatus');
            $table->integer('employeeStatus');
            $table->string('employeeId');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employeeperformance');
    }
}
