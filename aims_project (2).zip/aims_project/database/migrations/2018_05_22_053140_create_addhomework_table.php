<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAddhomeworkTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addhomework', function (Blueprint $table) {
            $table->increments('id');
            $table->string('session');
            $table->integer('classLevel');
            $table->string('class');
            $table->string('medium');
            $table->string('group');
            $table->string('shift');
            $table->string('section');
            $table->string('teacherName');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addhomework');
    }
}
