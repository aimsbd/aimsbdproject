<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePrevioustransactionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('previoustransaction', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('transactionCategory');
            $table->string('transactionName');
            $table->datetime('frpmDate');
            $table->datetime('toDate');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('previoustransaction');
    }
}
