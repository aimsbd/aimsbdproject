<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateItemslossTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('itemsloss', function (Blueprint $table) {
            $table->increments('id');
            $table->string('itemCategory');
            $table->string('itemName');
            $table->integer('pieceItem');
            $table->string('useItem');
            $table->string('lossItem');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('itemsloss');
    }
}
