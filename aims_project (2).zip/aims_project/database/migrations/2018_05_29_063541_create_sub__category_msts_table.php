<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSubCategoryMstsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sub__category_msts', function (Blueprint $table) {
            //$table->increments('id');
            $table->string('Sub_category_mstID')->primary();
            $table->string('Sub_category_Name');
            $table->string('delete_cd');
            $table->string('user');
            $table->string('Ip');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sub__category_msts');
    }
}
