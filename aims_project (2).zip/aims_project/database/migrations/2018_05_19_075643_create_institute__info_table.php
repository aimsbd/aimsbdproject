<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInstituteInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('institute__info', function (Blueprint $table) {
            $table->increments('id');
            $table->string('currentClassLevel');
            $table->integer('classLevelType');
            $table->integer('instituteCtegory');
            $table->string('instituteName');
            $table->string('instituteEIN');
            $table->string('town');
            $table->string('district');
            $table->string('instituteType');
            $table->string('contractPerson');
            $table->string('phoneNumber');
            $table->string('email');
            $table->string('boardName');
            $table->string('thana');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('institute__info');
    }
}
