<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCategoryMstsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('category_msts', function (Blueprint $table) {
            $table->string('Category_mstID');
            $table->string('Category_Name');
            $table->string('Delete_Cd');
            $table->string('User');
            $table->string('IP');
            $table->timestamps();
            $table->primary('Category_mstID');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('category_msts');
    }
}
