<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAccesspermissionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('accesspermission', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('pageId');
            $table->integer('roleId');
            $table->integer('list');
            $table->integer('edit');
            $table->integer('delete');
            $table->integer('status');
            $table->datetime('createDate');
            $table->string('createBy');
            $table->datetime('updateDate');
            $table->string('updateBy');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('accesspermission');
    }
}
