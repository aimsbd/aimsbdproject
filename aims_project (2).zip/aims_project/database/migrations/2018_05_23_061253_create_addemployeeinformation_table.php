<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAddemployeeinformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addemployeeinformation', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('employeeType');
            $table->string('designation');
            $table->string('department');
            $table->integer('employmentStatus');
            $table->datetime('joiningDate');
            $table->datetime('retirementDate');
            $table->integer('employeeStatus');
            $table->integer('employeePosition');
            $table->string('firstName');
            $table->string('middleName');
            $table->string('lastName');
            $table->string('fatherName');
            $table->string('motherName');
            $table->integer('gender');
            $table->string('mobileNumber');
            $table->datetime('dateofBirth');
            $table->string('birthregistrationNumber');
            $table->string('nationality');
            $table->string('nationalIdnumber');
            $table->string('bloodGroup');
            $table->integer('maritalstatus');
            $table->string('emailAddress');
            $table->string('presentAddress');
            $table->string('employeeImage');
            $table->string('indexNo');
            $table->integer('programType');
            $table->string('discipline');
            $table->string('grade');
            $table->integer('passingYear');
            $table->string('board');
            $table->integer('hr');
            $table->integer('hrAdmin');
            $table->integer('academic');
            $table->integer('academicAdmin');
            $table->integer('finance');
            $table->integer('financeAdmin');
            $table->integer('admissionResult');
            $table->integer('admissionresultAdmin');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addemployeeinformation');
    }
}
